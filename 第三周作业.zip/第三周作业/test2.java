package mould;

public class test2 {
        public static void main(String[] args) {
            Demo01 te=new Demo01();
            Demo01 te1=new Demo01();
            new Thread(te,"哦哦").start();
            new Thread(te1,"嗯嗯").start();
        }
    }

