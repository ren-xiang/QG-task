import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

/**
 * 客户端类
 */
public class Client {

    private static final String LOG = "In class : Client -->";

    private String host;
    private int port;

    private volatile int ticket;

    public int getTicket() {
        return ticket;
    }

    public Client(){}
    public Client(String host, int port) {
        this.host = host;
        this.port = port;
        ticket = 0;
    }

    public static void main(String[] args) throws IOException {
        new Client("127.0.0.1", 8806).start();//127.0.0.1
        //xianchen ao=new xianchen();
       // new Thread(ao,"d").start();
    }

    public void start() throws IOException {
        System.out.println("你要抢的票数是：");
        Scanner op=new Scanner(System.in);
        int opp=op.nextInt();
        int[] a = new int[1];
        final String[] da = new String[1];

        Constant.Operation oper = new Constant.Operation() {
        @Override
        public Constant sell() {
            da[0] = "a";
            ticket++;
            System.out.println(Thread.currentThread().getName()+"抢票成功！，现有票数"+ticket);
            return Constant.SUCCESS;
        }

        @Override
        public Constant refund() {
            a[0] = new Client().ticket;
            if(ticket>0){
                ticket--;
                System.out.println(Thread.currentThread().getName()+"退票成功！，现有票数"+ticket);
                da[0] ="b";
            }
            else {
                System.out.println(Thread.currentThread().getName()+"退票失败！，现有票数"+ticket);
                da[0]="c";
            }
            return Constant.FAIL;
        }
    };
        Client2 kuai=new Client2();
        while (ticket<opp&&(ticket+ kuai.getTicket()<200)) {
            System.out.println(kuai.getTicket());
                Socket socket = new Socket(this.host, this.port);
                OutputStream os = socket.getOutputStream();
                Constant.random(oper);
                os.write(da[0].getBytes());
                /*InputStream is = socket.getInputStream();
                byte[] bytes = new byte[1024];
                int len = is.read(bytes);
                System.out.println(new String(bytes, 0, len, "UTF-8"));*/

            //socket.close();
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //TODO 实现逻辑
        }

    }
}


