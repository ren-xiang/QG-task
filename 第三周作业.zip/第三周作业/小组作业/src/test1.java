public class test1 {
    public static void main(String[] args) {
        Demo01 te=new Demo01();
        Demo01 te1=new Demo01();
        new Thread(te,"USER1").start();
        new Thread(te1,"USER2").start();
    }
}
