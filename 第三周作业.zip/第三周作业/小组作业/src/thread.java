import java.io.IOException;

public class xianchen implements Runnable  {
    @Override
        public void run() {
            try {
                new Client("127.0.0.1", 8806).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
}

