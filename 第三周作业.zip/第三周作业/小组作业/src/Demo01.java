import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

/**
 * 客户端类
 */
public class Demo01 implements Runnable{

    private static final String LOG = "In class : Client -->";

    private String host;
    private int port;

    public  int ticket;

    public Demo01(){}
    public Demo01(String host, int port) {
        this.host = host;
        this.port = port;
        ticket = 0;
    }

    public void run(){
        try {
            new Demo01("172.17.73.182", 8806).start();//172.17.73.182
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /*ublic static void main(String[] args) throws IOException {
        new Client("172.17.73.182", 8806).start();//172.17.73.182
        //xianchen ao=new xianchen();
        // new Thread(ao,"d").start();
    }*/

    public void start() throws IOException {
        //System.out.println("你要抢的票数是：");
        //Scanner op=new Scanner(System.in);
        int opp=200;
        String[] da = new String[1];
        Constant.Operation oper = new Constant.Operation() {
            @Override
            public Constant sell() {
                da[0] = "a";
                ticket++;
                System.out.println(Thread.currentThread().getName()+"抢票成功！，现有票数"+ticket);
                return Constant.SUCCESS;
            }

            @Override
            public Constant refund() {
                if(ticket>0){
                    ticket--;
                    System.out.println(Thread.currentThread().getName()+"退票成功！，现有票数"+ticket);
                    da[0] ="b";
                }
                else {
                    System.out.println(Thread.currentThread().getName()+"退票失败！，现有票数"+ticket);
                    da[0]="c";
                }
                return Constant.FAIL;
            }
        };
        while (ticket<opp) {
           synchronized (this){
            Socket socket = new Socket(this.host, this.port);
            OutputStream os = socket.getOutputStream();
            Constant.random(oper);
            os.write(da[0].getBytes());}
                /*InputStream is = socket.getInputStream();
                byte[] bytes = new byte[1024];
                int len = is.read(bytes);
                System.out.println(new String(bytes, 0, len, "UTF-8"));*/

            //socket.close();
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //TODO 实现逻辑
        }

    }

}


