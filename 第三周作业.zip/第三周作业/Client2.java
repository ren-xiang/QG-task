package mould;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

/**
 * 客户端类
 */
public class Client2  {
    public int getTicket() {
        return ticket;
    }

    private static final String LOG = "In class : Client -->";

    private String host;
    private int port;

    private volatile int ticket;

    public Client2(){}
    public Client2(String host, int port) {
        this.host = host;
        this.port = port;
        ticket = 0;
    }
    public void run() {
        try {
            new Client("172.17.73.182", 8806).start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) throws IOException {
        //Client2 ao=new Client2();
       // new Thread(ao,"副抢票人").start();
        new Client2("172.17.73.182", 8806).start();//172.17.73.182


    }

    public void start() throws IOException {
        System.out.println("你要抢的票数是：");
        Thread.currentThread().setName("主票人");
        Scanner op=new Scanner(System.in);
        int opp=op.nextInt();
        int[] a = new int[1];
        final String[] da = new String[1];

        Constant.Operation oper = new Constant.Operation() {
            @Override
            public Constant sell() {
                da[0] = "a";
                ticket++;
                System.out.println(Thread.currentThread().getName()+"抢票成功！，现有票数"+ticket);
                return Constant.SUCCESS;
            }

            @Override
            public Constant refund() {
                a[0] = new Client2().ticket;
                if(ticket>0){
                    ticket--;
                    System.out.println(Thread.currentThread().getName()+"退票成功！，现有票数"+ticket);
                    da[0] ="b";
                }
                else {
                    System.out.println(Thread.currentThread().getName()+"退票失败！，现有票数"+ticket);
                    da[0]="c";
                }
                return Constant.FAIL;
            }
        };


        while (ticket<opp) {
            Client kuai=new Client();
            System.out.println(kuai.getTicket());
            Socket socket = new Socket(this.host, this.port);
            OutputStream os = socket.getOutputStream();
            Constant.random(oper);
            os.write(da[0].getBytes());
                /*InputStream is = socket.getInputStream();
                byte[] bytes = new byte[1024];
                int len = is.read(bytes);
                System.out.println(new String(bytes, 0, len, "UTF-8"));*/

            //socket.close();
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //TODO 实现逻辑
        }
    }
}





