package mould;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 服务端类
 */
public class Server {

    private static final String LOG = "In class : Server -->";

    private int port;
    private volatile int ticket;

    private Server(int ticket, int port){
        this.ticket = ticket;
        this.port = port;


    }

    public static void main(String[] args) throws IOException {
        Server ou=new Server(20000, 8806).start();
    }

    private Server start() throws IOException {
        ServerSocket server = new ServerSocket(this.port);
        while (true) {
            synchronized (this) {
                Socket socket = server.accept();
                InputStream is = socket.getInputStream();
            /*OutputStream os=socket.getOutputStream();
            os.write(ttue.getBytes());*/
                byte[] bytes = new byte[1024];
                int len;
                len = is.read(bytes);
                String ac = new String(bytes, 0, len, "UTF-8");
                if ("a".equals(ac)) this.ticket--;
                else if ("b".equals(ac)) this.ticket++;
                else ;
                if (ticket == 0) {
                    System.out.println("票已经售空！");
                    break;
                }
                System.out.println("剩余的票数是：" + this.ticket);
            }
        }
        return null;
    }
        //socket.close();
        //server.close();
        //TODO 实现逻辑
}
