package mould;

import java.io.IOException;

public class xianchen implements Runnable  {
    @Override
        public void run() {
            try {
                new Client("172.17.73.182", 8806).start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
}

