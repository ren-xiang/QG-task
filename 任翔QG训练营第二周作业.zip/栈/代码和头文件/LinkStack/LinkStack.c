#include <stdio.h>
#include <malloc.h>
#include <stdio.h>
#include <stdbool.h>
#include "../head/LinkStack.h"
//��ջ(����������)
Status initLStack(LinkStack *s)   //��ʼ��
{
      s->top = NULL;
      s->count = -1;
        return SUCCESS;
}

Status isEmptyLStack(LinkStack *s) //�ж���ջ�Ƿ�Ϊ��
{
        if ( s == NULL)
        {
        printf(" stack is not exist\n") ;//��������������ľͻᱨ�� ��������UTF-8���Ǵ���
        return ERROR;
        }
        else if( s->top == NULL ) return SUCCESS;
        else if (s !=NULL && s->top != NULL)
        {
         printf("stack is not empty\n");
         return ERROR;
        }

}
Status getTopLStack(LinkStack *s,ElemType *e)  //�õ�ջ��Ԫ��
{
        if ( s == NULL) return ERROR;
        else if( s->top == NULL )
                return ERROR;
        *e = s->top->data;
                return SUCCESS;
}
Status clearLStack(LinkStack *s)   //���ջ
{
        if (s == NULL) return ERROR;
        else if( s->top == NULL)
                return SUCCESS;
        {
                while( s->top )
                {
                        free( s->top );
                }
                return SUCCESS;
        }
}
Status destroyLStack(LinkStack *s)   //����ջ
{
        if ( s == NULL )return ERROR;

        free(s->top);
        s->top = NULL;
        s = NULL;
        return SUCCESS;

}
Status LStackLength(LinkStack *s,int *length)    //���ջ����
{
        if( !(s != NULL&&s->top != NULL) )
         return ERROR;
        else{
                 /*while( s->top != NULL )
                {
                        *length++;
                        s->top = s->top->next;
                }
                *length+=1;*/
                *length = s->count+1;
        }
         return SUCCESS;

}
Status pushLStack(LinkStack *s,ElemType data)   //��ջ
{
        if( s == NULL ) return ERROR;
        else
        {
        LinkStackPtr a = (LinkStackPtr) malloc( sizeof (StackNode));
        a->data = data;
        a->next = s->top;
        s->top  = a;
        s->count ++;
        return SUCCESS;
        }

}
Status popLStack(LinkStack *s,ElemType *data)   //��ջ
{
        if( s == NULL )
                return ERROR;
        LinkStackPtr p;
        if( s->top == NULL )
                return ERROR;
        *data = s->top->data;
        p = s->top;
        s->top=s->top->next;
        free(p);
        s->count--;
        return SUCCESS;
}
