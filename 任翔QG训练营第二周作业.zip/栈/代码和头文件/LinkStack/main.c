#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <malloc.h>
#include "../head/LinkStack.h"

void start();

int main()
{
    start();
    return 0;
}

void start()
{
    while (1)
    {
        LinkStack *s = NULL;
        ElemType data;
        int *length = (int*)malloc(sizeof(4));
        int t;
        while (1)
        {
            fflush(stdin);
            system("cls");
            puts("初始化栈------------1");
            puts("判断栈是否为空------2");
            puts("得到栈顶元素--------3");
            puts("清空栈--------------4");
            puts("销毁栈--------------5");
            puts("获得栈的长度--------6");
            puts("元素入栈------------7");
            puts("栈顶元素出栈--------8");
            puts("退出----------------0");

            scanf("%d",&t);
            switch (t)
            {
            case (1):
                    s = (LinkStack*)malloc(sizeof(LinkStack));
                if (initLStack(s))
                {
                    printf("初始化成功");
                }
                else
                {
                    printf("初始化失败");
                }

                break;
            case (2):
                if (isEmptyLStack(s))
                        printf("栈为空\n" );
                else ;

                break;
            case (3):
                if (getTopLStack(s, &data))
                {
                    printf("栈顶元素是%d\n", data);
                }
                else
                {
                    printf("无法获得栈顶元素\n");
                }
                break;
            case (4):
                if (clearLStack(s))
                {
                    printf("清除成功");
                }
                else
                {
                    printf("清除失败");
                }
                break;
            case (5):
                if (destroyLStack(s))
                {
                    printf("销毁成功");
                    s = NULL;
                }
                else
                {
                    printf("销毁失败");
                }
                break;
            case (6):
                if (LStackLength(s, length))
                {
                    printf("栈的长度是%d\n", *length);
                }
                else
                        printf("查询错误\n");

                break;
            case (7):
                puts("请输入想要入栈的元素");
                scanf("%d", &data);
                if (pushLStack(s, data))
                {
                    printf("元素%d入栈成功\n", data);
                }
                else
                {
                    printf("元素%d入栈失败\n", data);
                }
                break;
            case (8):
                if (popLStack(s, &data))
                {
                    printf("栈顶元素%d成功出栈\n", data);
                }
                else
                {
                    puts("栈顶元素出栈失败");
                }
                break;
            case (0):
                exit(0);
            }
            system("pause");
        }
    }
}
