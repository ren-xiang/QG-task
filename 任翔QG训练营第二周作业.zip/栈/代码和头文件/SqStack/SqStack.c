#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>
#include "../head/SqStack.h"

//˳��ջ(���������)
Status initStack(SqStack *s,int sizes)  //��ʼ��ջ
{
        s->size = sizes;
        s->top = -1;
        s->elem = ( ElemType * )malloc( sizeof ( ElemType ));
        return SUCCESS;
}

Status isEmptyStack(SqStack *s)   //�ж�ջ�Ƿ�Ϊ��
{
      if ( s->top == -1 )
                return SUCCESS;

      else      return ERROR;
}

Status getTopStack(SqStack *s,ElemType *e)   //�õ�ջ��Ԫ��
{
        if ( s->top == -1 )
                return ERROR;
        else
        {
                *e = s->elem [ s->top ];
                return SUCCESS;
                }
}
Status clearStack(SqStack *s)   //���ջ
{
        if ( s->top == -1 )
                return SUCCESS;
        else {
                while ( s->top != -1 )
                s->top--;
                return SUCCESS;
        }
}
Status destroyStack(SqStack *s)  //����ջ
{
        free( s->elem );
        ElemType *elem = NULL;
        return SUCCESS;
}
Status stackLength(SqStack *s,int *length)   //���ջ����
{
        *length = 0;
        if ( s->top<0 && ((s->top) > (s->size)) )
                return ERROR;

        else
        {
                *length = s->top+1;
                return SUCCESS;
        }
}
Status pushStack(SqStack *s,ElemType data)  //��ջ
{
        if ( s-> top == (s->size)-1)
               return ERROR;

        s->top++;
        s->elem[s->top] = data;
                return SUCCESS;
}

Status popStack(SqStack *s,ElemType *data)   //��ջ
{
        if (s->top == -1)
                return ERROR;

        *data = s->elem[s->top];
        s->top--;
                return SUCCESS;
}

